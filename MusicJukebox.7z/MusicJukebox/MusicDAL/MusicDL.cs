﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MusicSystemBL;
using System.Configuration;

namespace MusicDAL
{
    public class MusicDL
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static MusicDL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public void AddCustomer(Customer c)
        {
            int id = 0;
            using (con = new SqlConnection(conStr))
            {
                cmd = new SqlCommand("tamal.AddCust", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@cid", c.CustomerID);

                cmd.Parameters.AddWithValue("@cname", c.CustName);
                cmd.Parameters.AddWithValue("@addr", c.Address);
                cmd.Parameters.AddWithValue("@dob", c.DOB);
                cmd.Parameters.AddWithValue("@city", c.City);
                cmd.Parameters.AddWithValue("@pass", c.Password);
                cmd.Parameters.AddWithValue("@mobile", c.MobileNo);
                con.Open();
                cmd.ExecuteNonQuery();

            }

        }
        public bool LoginCustomer(Customer c)
        {
            using (con = new SqlConnection(conStr))
            {
                cmd = new SqlCommand("tamal.LoginCust", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@cid", c.CustomerID);
                cmd.Parameters.AddWithValue("@pass", c.Password);
                con.Open();
                int login = (int)cmd.ExecuteScalar();
                if (login == 1)
                {
                    return true;
                }
                else
                    return false;
            }
        }
        public void AddEmployee(Employee e)
        {
            int id = 0;
            using (con = new SqlConnection(conStr))
            {
                cmd = new SqlCommand("tamal.AddEmp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@eid", e.EmployeeID);

                cmd.Parameters.AddWithValue("@ename", e.EmpName);
                cmd.Parameters.AddWithValue("@addr", e.Address);
                cmd.Parameters.AddWithValue("@dob", e.DOB);
                cmd.Parameters.AddWithValue("@city", e.City);
                cmd.Parameters.AddWithValue("@pass", e.Password);
                cmd.Parameters.AddWithValue("@mobile", e.MobileNo);
                con.Open();
                cmd.ExecuteNonQuery();

            }
        }

        public bool LoginEmployee(Employee e)
        {
            using (con = new SqlConnection(conStr))
            {
                cmd = new SqlCommand("tamal.LoginEmp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@eid", e.EmployeeID);
                cmd.Parameters.AddWithValue("@pass", e.Password);
                con.Open();
                int login = (int)cmd.ExecuteScalar();
                if (login == 1)
                {
                    return true;
                }
                else
                    return false;
            }
        }
        public bool SearchCustomer(Customer c)
        {
            using(con=new SqlConnection(conStr))
            {
                cmd = new SqlCommand("tamal.SearchCust",con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@cid", c.CustomerID);
                con.Open();
                int search = (int)cmd.ExecuteScalar();
                if (search == 1)
                    return true;
                else
                    return false;
            }
        }
        public bool SearchEmployee(Employee e)
        {
            using (con = new SqlConnection(conStr))
            {
                cmd = new SqlCommand("tamal.SearchEmp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@cid",e.EmployeeID);
                con.Open();
                int search = (int)cmd.ExecuteScalar();
                if (search == 1)
                    return true;
                else
                    return false;
            }
        }
        public void UpdateCustomer(Customer c)
        {
            using(con=new SqlConnection(conStr))
            {
                cmd = new SqlCommand("tamal.UpCust", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@eid", c.CustomerID);

                cmd.Parameters.AddWithValue("@ename", c.CustName);
                cmd.Parameters.AddWithValue("@addr", c.Address);
                cmd.Parameters.AddWithValue("@dob", c.DOB);
                cmd.Parameters.AddWithValue("@city", c.City);
                cmd.Parameters.AddWithValue("@pass", c.Password);
                cmd.Parameters.AddWithValue("@mobile", c.MobileNo);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public void UpdateEmployee(Employee e)
        {
            using(con=new SqlConnection(conStr))
            {
                cmd = new SqlCommand("tamal.UpEmp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@eid", e.EmployeeID);

                cmd.Parameters.AddWithValue("@ename", e.EmpName);
                cmd.Parameters.AddWithValue("@addr", e.Address);
                cmd.Parameters.AddWithValue("@dob", e.DOB);
                cmd.Parameters.AddWithValue("@city", e.City);
                cmd.Parameters.AddWithValue("@pass", e.Password);
                cmd.Parameters.AddWithValue("@mobile", e.MobileNo);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
        public DataTable SearchAlbumBySinger(string singer)
        {
            DataTable dt = null;
            using(con=new SqlConnection(conStr))
            {
                cmd = new SqlCommand("tamal.SearchAlbumbySinger", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@singer", singer);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            return dt;
        }
    }
}
