﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MusicDAL;

namespace MusicSystemBL
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string CustName { get; set; }
        public string Address { get; set; }
        public DateTime DOB { get; set; }
        public string City { get; set; }
        public string Password { get; set; }
        public string MobileNo { get; set; }

        public void AddCustomer(Customer c)
        {
            MusicDL dL = new MusicDL();
           dL.AddCustomer(c);
        }
        public bool LoginCustomer(Customer c)
        {
            MusicDL dl = new MusicDL();
            return dl.LoginCustomer(c);
        }
        public bool SearchCustomer(Customer c)
        {
            MusicDL dl = new MusicDL();
            return dl.SearchCustomer(c);
        }
        public void UpdateCustomer(Customer c)
        {
            MusicDL dl = new MusicDL();
            dl.UpdateCustomer(c);
        }
        public DataTable SearchAlbumBySinger(string singer)
        {
            MusicDL dL = new MusicDL();
            return dL.SearchAlbumBySinger(singer);
        }
      
    }
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string EmpName { get; set; }
        public string Address { get; set; }
        public DateTime DOB { get; set; }
        public string City { get; set; }
        public string Password { get; set; }
        public string MobileNo { get; set; }

        public void AddEmployee(Employee e)
        {
            MusicDL dL = new MusicDL();
            dL.AddEmployee(e);
        }
        public bool LoginEmployee(Employee e)
        {
            MusicDL dl = new MusicDL();
            return dl.LoginEmployee(e);
        }
        public bool SearchEmployee(Employee e)
        {
            MusicDL dl = new MusicDL();
            return dl.LoginEmployee(e);
        }
        public void UpdateEmployee(Employee e)
        {
            MusicDL dl = new MusicDL();
            dl.UpdateEmployee(e);
        }
    }
    public class MusicOrder
    {
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }
        public DateTime DOB { get; set; }
        public int OrderPaymentID { get; set; }
        public string Password { get; set; }
        public string MobileNo { get; set; }
    }
    public class Album
    {
        public int AlbumID { get; set; }
        public string AlbumName { get; set; }
        public string Category { get; set; }
        public int No_Of_songs { get; set; }
        public DateTime Release_Date { get; set; }
        public string Company { get; set; }
        public decimal Price { get; set; }
        public string Language { get; set; }
    }
    public class Songs
    {
        public int SongID { get; set; }
        public string SongName { get; set; }
        public string Singer { get; set; }
        public string Movie { get; set; }
        public string ComposedBy { get; set; }
        public string Lyrics { get; set; }
        public int Year { get; set; }
        public int AlbumID { get; set; }
        public string Language { get; set; }
    }
}
